// Leia o arquivo README.md ou README.html antes de iniciar este exercício!
// para compilar use:

// gcc q1.c -o q1 -pthread

#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    sem_t *s1;
    sem_t *s2;
    sem_t *s3;
    sem_t *s4;
    sem_t *rdv1;
    sem_t *rdv2;
} thread_arg;

void *thread1(void *_arg) {
    thread_arg *arg = _arg;

    printf("A\n");

    sem_post(arg->s1);
    sem_post(arg->s3);

    sem_wait(arg->s1);
    sem_wait(arg->s1);

    printf("C\n");

    sem_post(arg->s1);
    sem_post(arg->s2);
    sem_post(arg->s4);

    sem_wait(arg->s1);
    sem_wait(arg->s1);

    printf("E\n");

    return NULL;
}

void *thread2(void *_arg) {
    thread_arg *arg = _arg;

    sem_wait(arg->s2);
    sem_wait(arg->s2);

    printf("F\n");

    return NULL;
}

void *thread3(void *_arg) {
    thread_arg *arg = _arg;

    sem_wait(arg->s3);
    sem_wait(arg->s3);

    printf("D\n");

    sem_post(arg->s1);
    sem_post(arg->s2);
    sem_post(arg->s4);

    return NULL;
}

void *thread4(void *_arg) {
    thread_arg *arg = _arg;

    printf("B\n");

    sem_post(arg->s1);
    sem_post(arg->s3);

    sem_wait(arg->s4);
    sem_wait(arg->s4);

    printf("G\n");

    return NULL;
}

int main(int argc, char *argv[]) {

    // Crie TODAS as threads. Voce deve utilizar semaforos para sincronizacao.

    // Espere por TODAS as threads

    pthread_t *threads = malloc(4 * sizeof(pthread_t));
    thread_arg *arg = malloc(sizeof(thread_arg));

    sem_t *s1 = malloc(sizeof(sem_t));
    sem_t *s2 = malloc(sizeof(sem_t));
    sem_t *s3 = malloc(sizeof(sem_t));
    sem_t *s4 = malloc(sizeof(sem_t));
    sem_t *rdv1 = malloc(sizeof(sem_t));
    sem_t *rdv2 = malloc(sizeof(sem_t));

    sem_init(s1, 0, 0);
    sem_init(s2, 0, 0);
    sem_init(s3, 0, 0);
    sem_init(s4, 0, 0);
    sem_init(rdv1, 0, 0);
    sem_init(rdv2, 0, 0);

    arg->s1 = s1;
    arg->s2 = s2;
    arg->s3 = s3;
    arg->s4 = s4;
    arg->rdv1 = rdv1;
    arg->rdv2 = rdv2;

    pthread_create(&threads[0], NULL, thread1, arg);
    pthread_create(&threads[1], NULL, thread2, arg);
    pthread_create(&threads[2], NULL, thread3, arg);
    pthread_create(&threads[3], NULL, thread4, arg);

    for (int i = 0; i < 4; i++) {
        pthread_join(threads[i], NULL);
    }

    sem_destroy(s1);
    sem_destroy(s2);
    sem_destroy(s3);
    sem_destroy(s4);
    sem_destroy(rdv1);
    sem_destroy(rdv2);

    free(threads);
    free(arg);
    free(s1);
    free(s2);
    free(s3);
    free(s4);
    free(rdv1);
    free(rdv2);

    return 0;
}